<?php
__( 'SuperCacher Settings', 'sg-cachepress' );
__( 'Environment Optimization', 'sg-cachepress' );
__( 'Frontend Optimization', 'sg-cachepress' );
__( 'Image Optimization', 'sg-cachepress' );